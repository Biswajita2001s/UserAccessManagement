package com.org;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/requestAccess")
public class RequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String softwareName = request.getParameter("software_name");
        String accessType = request.getParameter("access_type");
        String reason = request.getParameter("reason");

        try {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/UserAccessManagement", "postgres", "root");

            // Query to get user_id and software_id
            String sql = "INSERT INTO requests (user_id, software_id, access_type, reason, status) VALUES (?, ?, ?, ?, 'Pending')";
            PreparedStatement stmt = conn.prepareStatement(sql);
            // You'd need to look up user_id and software_id first
            stmt.setInt(1, 1); // Placeholder for user_id
            stmt.setInt(2, 1); // Placeholder for software_id
            stmt.setString(3, accessType);
            stmt.setString(4, reason);
            stmt.executeUpdate();

            response.sendRedirect("requestAccess.jsp?success=true");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

